<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

/**
 * Class to manage a 403 - Forbidden response.
 */
class Forbidden_Exception extends Remote_Request_Exception {

}
