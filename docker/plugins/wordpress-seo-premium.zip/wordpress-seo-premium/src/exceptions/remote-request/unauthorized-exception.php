<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

/**
 * Class to manage a 401 - unauthorized response.
 */
class Unauthorized_Exception extends Remote_Request_Exception {

}
