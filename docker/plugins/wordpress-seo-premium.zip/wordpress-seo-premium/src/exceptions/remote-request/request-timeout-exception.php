<?php

namespace Yoast\WP\SEO\Premium\Exceptions\Remote_Request;

/**
 * Class to manage a 408 - request timeout exception
 */
class Request_Timeout_Exception extends Remote_Request_Exception {

}
